# Quiz-contest
You are required to create a quiz contest. There are five quiz webpages each showing a question and four options. If the option is correct, it must move to the next questions and if the answer is wrong displays a message "you lost". After completing all correct answers, it must store the name of the winner in the database
